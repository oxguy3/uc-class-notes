# Homework 4 database screenshots

CS 4092, Summer 2018

Martina Desender (M07771641) and Hayden Schiff (M12752592)

## department

<img src="assets/image-20180713144727844.png" style="zoom:50%">

## dependent

<img src="assets/image-20180713144748097.png" style="zoom:50%">

<div style="page-break-after: always;"></div>

## dept_locations

<img src="assets/image-20180713144821562.png" style="zoom:50%">

## employee

<img src="assets/image-20180713145002781.png" style="zoom:50%">

## project

<img src="assets/image-20180713145028752.png" style="zoom:50%">

<div style="page-break-after: always;"></div>

## works_on

<img src="assets/image-20180713145257458.png" style="zoom:50%">